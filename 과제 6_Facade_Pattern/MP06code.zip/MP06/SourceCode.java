public class SourceCode {
    String codeFileName;

    public SourceCode(String fileName) {
        this.codeFileName = fileName;
    }

    public void setCodeFileName(String codeFileName) {
        this.codeFileName = codeFileName;
    }

    public String getCodeFileName() {
        return codeFileName;
    }
}
