public class ObjectCode {
    private String objFileName;

    public ObjectCode(String fileName) {
        objFileName = fileName;
    }

    public String getObjectFileName() {
        return objFileName;
    }

    public void setObjectFileName(String fileName) {
        this.objFileName = fileName;
    }
}
