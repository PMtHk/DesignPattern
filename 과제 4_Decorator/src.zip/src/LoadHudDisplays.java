import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class LoadHudDisplays implements LoadDisplayInterface {
  private BufferedReader br;
  public LoadHudDisplays(String filename) {
    try {
      br = new BufferedReader(new FileReader(filename));
    } catch (Exception e) {
      System.out.println(e);
    }
  }

  @Override
  public ArrayList<String> load() {
    ArrayList<String> list;
    
    String str;
    while((str = br.readLine()) != null){
      list.add(str);
    }
    return list;


  }

  
}
