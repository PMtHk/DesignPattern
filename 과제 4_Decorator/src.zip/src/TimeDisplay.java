public class TimeDisplay {
  
}
