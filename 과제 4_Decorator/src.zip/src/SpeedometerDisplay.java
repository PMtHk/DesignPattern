public class SpeedometerDisplay {
  
}
