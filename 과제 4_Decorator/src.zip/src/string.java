
public class string {

}
