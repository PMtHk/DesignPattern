public class WeatherDisplay {
  
}
